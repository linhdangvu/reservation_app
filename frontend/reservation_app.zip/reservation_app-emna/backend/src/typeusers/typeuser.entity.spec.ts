import { TypeUser } from './typeuser.entity';

describe('TypeUser', () => {
  it('should be defined', () => {
    expect(new TypeUser()).toBeDefined();
  });
});
